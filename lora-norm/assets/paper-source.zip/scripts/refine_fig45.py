#!/usr/bin/env python3
"""Refined, aligned interval figures for RQ2 and RQ3.

Run after scripts/redraw_section5.py. The input statistics are unchanged.
No resampling, filtering, or model inference is performed by this script.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import Rectangle

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'sources/section5_redraw'
OUT = ROOT / 'figures'
for path in Path('/usr/share/fonts/opentype/urw-base35').glob('NimbusRoman-*.otf'):
    fm.fontManager.addfont(str(path))
INK = '#263238'
ACCENT = '#16736F'
INTERVAL = '#83A6A3'
MUTED = '#737D81'
LIGHT = '#DCE3E2'
RULE = '#ADB9B9'
TINTS = ['#F0F4F7', '#F1F5F1', '#F7F3ED']  # mist blue, sage, warm sand
DIAGNOSTIC_TINT = '#F5F4F1'
FIGURE_SCALE = 0.86
VERTICAL_SCALE = 0.90
FONT_SCALE = 0.86
plt.rcParams.update({
    'font.family':'serif',
    'font.serif':['Nimbus Roman','STIXGeneral','DejaVu Serif'],
    'mathtext.fontset':'stix', 'font.size':9.3,
    'text.color':INK, 'pdf.fonttype':42, 'ps.fonttype':42,
    'svg.fonttype':'none', 'figure.facecolor':'white',
    'savefig.facecolor':'white', 'axes.unicode_minus':True,
})

def canvas(height):
    fig=plt.figure(figsize=(5.5*FIGURE_SCALE,height/72*FIGURE_SCALE*VERTICAL_SCALE))
    ax=fig.add_axes([0,0,1,1])
    ax.set_xlim(0,396);ax.set_ylim(0,height);ax.axis('off')
    return fig,ax

def text(ax,x,y,s,size=9.3,color=INK,ha='left',**kw):
    return ax.text(x,y,s,fontsize=max(7.0,size*FONT_SCALE),color=color,ha=ha,va='center',**kw)

def line(ax,x0,x1,y,color=LIGHT,lw=.5):
    ax.plot([x0,x1],[y,y],color=color,lw=lw,solid_capstyle='butt',zorder=1)

def ci(ax,x,y,lo,hi,mapx,color=ACCENT,ms=4.3):
    ax.plot([mapx(lo),mapx(hi)],[y,y],color=INTERVAL,lw=1.4,
            solid_capstyle='round',zorder=3)
    ax.plot(mapx(x),y,'o',ms=ms,mfc=color,mec='white',mew=.6,zorder=4)

def scale(ax,x0,x1,y,lim,ticks,labels=None,guide=None):
    lo,hi=lim
    fn=lambda v:x0+(v-lo)/(hi-lo)*(x1-x0)
    line(ax,x0,x1,y,color=LIGHT,lw=.55)
    for i,t in enumerate(ticks):
        xx=fn(t)
        ax.plot([xx,xx],[y,y-2],lw=.5,color=RULE)
        text(ax,xx,y-7,str(t) if labels is None else labels[i],size=8.0,color=MUTED,ha='center')
    if guide is not None:
        xx=fn(guide[0]);ax.plot([xx,xx],[guide[1],guide[2]],color=RULE,
                               lw=.55,ls=(0,(1.7,2.4)),zorder=1)
    return fn

def save(fig,stem):
    for ax in fig.axes:
        for artist in ax.lines:
            artist.set_linewidth(artist.get_linewidth()*FIGURE_SCALE)
            artist.set_markersize(artist.get_markersize()*FIGURE_SCALE)
            artist.set_markeredgewidth(artist.get_markeredgewidth()*FIGURE_SCALE)
    for ext in ['pdf','svg','png']:
        fig.savefig(OUT/f'{stem}.{ext}',dpi=320)
    plt.close(fig)

def matched_strength():
    df=pd.read_csv(SRC/'four_method_paired_ci.tsv',sep='\t')
    fig,ax=canvas(113)
    # Three metric columns each have a plot and a right-aligned numerical column.
    starts=[86,191,296]
    for x,tint in zip(starts,TINTS):
        ax.add_patch(Rectangle((x-5,20),103,91,facecolor=tint,
                               edgecolor='none',zorder=0))
    text(ax,3,103,'Control',size=8.8,color=MUTED)
    for x,label in zip(starts,['Target','Off-task','FG reduction']):
        text(ax,x,103,label,size=10.8)
    line(ax,3,392,93,color=RULE,lw=.65)
    ys=[78,55,32]
    for i,(name,y) in enumerate(zip(['Scalar-F','Scalar-E','Flat-E'],ys)):
        text(ax,3,y,name,size=10.1)
        if i<2:line(ax,3,392,y-11.5,lw=.35)
    metrics=['target','off_score','forgetting_gap']
    for x,metric in zip(starts,metrics):
        fn=scale(ax,x,x+70,16,(-1.95,2.65),[-1,0,1,2],['−1','0','1','2'],guide=(0,22,87))
        for c,y in zip(['scalar_f','scalar_e','flat_e'],ys):
            row=df[df.group.eq('overall')&df.comparison.eq('hns_f4_s1 minus '+c)&df.outcome.eq(metric)]
            assert len(row)==1 and row.iloc[0].n_checkpoints==18
            m,lo,hi=row.iloc[0][['mean_difference','ci_low','ci_high']].astype(float)
            if metric=='forgetting_gap':m,lo,hi=-m,-hi,-lo
            ci(ax,m,y,lo,hi,fn)
            text(ax,x+96,y,f'{m:+.2f}'.replace('-', '−'),size=9.8,ha='right')
    text(ax,3,9,'Difference (pp)',size=8.1,color=MUTED)
    save(fig,'fig5_2_matched_strength')

def functional_equalization():
    df=pd.read_csv(SRC/'equalization_plot_statistics.tsv',sep='\t')
    fig,ax=canvas(140)
    # Numeric values occupy a fixed position in every cell. Confidence intervals
    # sit below them, with explicit scales shared down each metric column.
    centers=[111,174,240,304,366]
    ax.add_patch(Rectangle((85,15),117,108,facecolor=DIAGNOSTIC_TINT,
                           edgecolor='none',zorder=0))
    for x,tint in zip(centers[2:],TINTS):
        ax.add_patch(Rectangle((x-26,15),54,108,facecolor=tint,
                               edgecolor='none',zorder=0))
    text(ax,87,133,'a',size=10,fontstyle='italic',color=ACCENT)
    text(ax,99,133,'Functional diagnostics',size=9.7)
    text(ax,216,133,'b',size=10,fontstyle='italic',color=ACCENT)
    text(ax,228,133,'Performance change (pp)',size=9.7)
    line(ax,87,201,124,color=RULE,lw=.55)
    line(ax,216,393,124,color=RULE,lw=.55)
    text(ax,3,115,'Method',size=8.8,color=MUTED)
    for x,label in zip(centers,['FPR','Energy / LoRA','Target','Off-task','FG reduction']):
        text(ax,x,115,label,size=9.4,ha='center')
    line(ax,3,393,106,color=RULE,lw=.65)
    ys=[94,71,48,25]
    names=['LoRA-Norm',r'F-HNS ($\alpha=0.5$)',r'F-HNS ($\alpha=1$)','Protected flat']
    for i,(y,label) in enumerate(zip(ys,names)):
        text(ax,3,y-3,label,size=9.3,color=ACCENT if i==0 else INK)
        if i<3:line(ax,3,393,y-12.5,lw=.35)
    specs=[('raw_fpr',(-.5,18),[0,8,16],['0','8','16']),
           ('energy_ratio',(-.006,.15),[0,.1],['0','0.1']),
           ('target_gain_hns',(-2.35,1),[-2,0,1],['−2','0','1']),
           ('off_score_gain_hns',(-1.02,.38),[-1,0],['−1','0']),
           ('fg_reduction_hns',(-.085,.21),[0,.2],['0','0.2'])]
    methods=['hns_f4_s1','functional_hns_a05','functional_hns_a10','functional_flat']
    for j,(x,spec) in enumerate(zip(centers,specs)):
        col,lim,ticks,labels=spec
        fn=scale(ax,x-23,x+23,13,lim,ticks,labels)
        for i,(m,y) in enumerate(zip(methods,ys)):
            if j>=2 and i==0:
                text(ax,x,y-3,'—',size=10,color=RULE,ha='center')
                continue
            row=df[df.method.eq(m)&df.metric.eq(col)]
            assert len(row)==1
            mean,lo,hi=row.iloc[0][['mean','ci_low','ci_high']].astype(float)
            number=f'{mean:.2f}' if j==0 else f'{mean:.4f}' if j==1 else f'{mean:+.2f}'
            text(ax,x,y+1,number.replace('-', '−'),size=9.4,ha='center',color=ACCENT if i==0 else INK)
            if j>=2:
                zero=fn(0)
                ax.plot([zero,zero],[y-10,y-4],color=RULE,lw=.65,zorder=2)
            ci(ax,mean,y-7,lo,hi,fn,color=ACCENT if j>=2 or i==0 else '#718484',ms=3.8)
    save(fig,'fig5_3_functional_equalization')

if __name__=='__main__':
    matched_strength()
    functional_equalization()
    print('Refined Figure 4 and Figure 5; statistics unchanged.')
