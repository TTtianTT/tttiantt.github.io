#!/usr/bin/env python3
"""Rebuild the three Section 5 figures from archived checkpoint results.

Run: python scripts/redraw_section5.py
Requires numpy, pandas, matplotlib. No network or model inference is used.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'sources/section5_redraw'
OUT = ROOT / 'figures'
OUT.mkdir(exist_ok=True)
raw = pd.read_csv(SRC / 'raw_results.tsv', sep='\t')
paired = pd.read_csv(SRC / 'four_method_paired_ci.tsv', sep='\t')

# Nimbus Roman is the freely distributed Times-compatible font used here.
# STIX/DejaVu Serif provide portable fallbacks on other machines.
for path in Path('/usr/share/fonts/opentype/urw-base35').glob('NimbusRoman-*.otf'):
    fm.fontManager.addfont(str(path))
INK = '#25303B'
MUTED = '#69737B'
RULE = '#CFD5D7'
GRID = '#E9EDEE'
TEAL = '#157F7A'
BLUE = '#376C9A'
GOLD = '#A8752F'
GREY = '#A4ADB4'
COLORS = [BLUE, TEAL, GOLD]
plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['Nimbus Roman', 'STIXGeneral', 'DejaVu Serif'],
    'mathtext.fontset': 'stix', 'font.size': 9.2,
    'axes.labelsize': 9, 'axes.titlesize': 9.5, 'axes.titleweight': 'bold',
    'axes.labelcolor': INK, 'text.color': INK, 'xtick.color': MUTED,
    'ytick.color': INK, 'xtick.labelsize': 8.5, 'ytick.labelsize': 9.1,
    'axes.edgecolor': RULE, 'axes.linewidth': .6,
    'xtick.major.size': 2.3, 'xtick.major.width': .55,
    'ytick.major.size': 0, 'pdf.fonttype': 42, 'ps.fonttype': 42,
    'svg.fonttype': 'none', 'savefig.facecolor': 'white',
    'figure.facecolor': 'white', 'axes.unicode_minus': True,
})

def save(fig, stem):
    # Fixed canvas, without bbox_inches='tight', keeps 5.5-inch paper sizing stable.
    for ext in ['pdf', 'svg', 'png']:
        fig.savefig(OUT / f'{stem}.{ext}', dpi=300)
    plt.close(fig)

def clean(ax, ticks, labels=None):
    for side in ['top', 'right', 'left']:
        ax.spines[side].set_visible(False)
    ax.xaxis.set_major_locator(FixedLocator(ticks))
    if labels is not None:
        ax.xaxis.set_major_formatter(FixedFormatter(labels))
    ax.xaxis.set_minor_locator(NullLocator())
    ax.grid(axis='x', color=GRID, linewidth=.55, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(axis='y', pad=5)

def point_ci(ax, mean, lo, hi, y, color, marker='o', size=4.4):
    # Symmetric-looking marks must still retain their asymmetric percentile limits.
    ax.errorbar(mean, y, xerr=[[max(0, mean-lo)], [max(0, hi-mean)]],
                fmt=marker, color=color, markersize=size, markeredgecolor='white',
                markeredgewidth=.45, elinewidth=1.25, capsize=2.0,
                capthick=.8, zorder=4)

def title(ax, label, color=INK):
    ax.set_title(label, loc='left', color=color, pad=7)

def method_values(method, col):
    frame = raw[raw.method.eq(method)]
    assert len(frame) == 18 and frame.checkpoint.is_unique
    return frame[col].to_numpy()

# RQ1: the current compact, grouped design lives in a standalone script.
def gain_redistribution():
    from refine_fig3 import gain_redistribution as refined_gain
    refined_gain()

# RQ2: original archived bootstrap intervals; a shared x scale across all metrics.
def matched_strength():
    fig = plt.figure(figsize=(5.5, 1.47))
    axs=[fig.add_axes([x,.28,.248,.50]) for x in [.160,.442,.724]]
    controls=['scalar_f','scalar_e','flat_e']
    for j,(ax,metric,label,color) in enumerate(zip(axs,
            ['target','off_score','forgetting_gap'],
            ['(a) Target','(b) Off-task','(c) FG reduction'],COLORS)):
        ax.set_xlim(-1.9,2.65);ax.set_ylim(-.48,2.54)
        ax.axvspan(0,2.65,color=color,alpha=.042,zorder=-2)
        clean(ax,[-1,0,1,2]);ax.axvline(0,color=MUTED,lw=.65,ls=(0,(3,3)))
        ax.set_yticks([2,1,0]);ax.set_yticklabels(['Scalar-F','Scalar-E','Flat-E'] if j==0 else [])
        for i,c in enumerate(controls):
            r=paired[paired.group.eq('overall') & paired.comparison.eq('hns_f4_s1 minus '+c)
                     & paired.outcome.eq(metric)]
            assert len(r)==1 and r.iloc[0].n_checkpoints==18
            r=r.iloc[0];m,lo,hi=r[['mean_difference','ci_low','ci_high']]
            if metric=='forgetting_gap':m,lo,hi=-m,-hi,-lo
            y=2-i
            point_ci(ax,m,lo,hi,y,color)
            ax.annotate(f'{m:+.2f}',(m,y),xytext=(0,5.5),textcoords='offset points',
                        ha='center',va='bottom',fontsize=9,color=color)
        title(ax,label,color)
    fig.text(.57,.025,'LoRA-Norm advantage (pp)   ·   positive favors LoRA-Norm',
             ha='center',fontsize=8.8,color=MUTED)
    save(fig,'fig5_2_matched_strength')

# RQ3: the same 2,000 draws and seed as the original figure.
# Fixed checkpoint order matches the original raw_results.tsv.
def equalization_stats():
    methods=['hns_f4_s1','functional_hns_a05','functional_hns_a10','functional_flat']
    columns=['raw_fpr','energy_ratio','target_gain_hns','off_score_gain_hns','fg_reduction_hns']
    ind=np.random.default_rng(20260914).integers(0,18,size=(2000,18))
    reference=list(raw[raw.method.eq(methods[0])].checkpoint)
    records=[]
    for m in methods:
        frame=raw[raw.method.eq(m)]
        assert list(frame.checkpoint)==reference
        for col in columns:
            v=frame[col].to_numpy();lo,hi=np.quantile(v[ind].mean(1),[.025,.975])
            records.append(dict(method=m,metric=col,mean=float(v.mean()),ci_low=float(lo),ci_high=float(hi)))
    stats=pd.DataFrame(records)
    stats.to_csv(SRC/'equalization_plot_statistics.tsv',sep='\t',index=False)
    return stats,methods,columns

def functional_equalization():
    stats,methods,columns=equalization_stats()
    fig=plt.figure(figsize=(5.5,1.83))
    xs=[.190,.342,.510,.673,.836];widths=[.119,.128,.132,.132,.139]
    axs=[fig.add_axes([x,.215,w,.52]) for x,w in zip(xs,widths)]
    specs=[((-1,18),[0,8,16],['0','8','16'],'FPR',INK),
           ((-.008,.151),[0,.1],['0','0.1'],'Energy / LoRA',INK),
           ((-2.35,1.0),[-2,0,1],['−2','0','1'],'Target',BLUE),
           ((-1.02,.38),[-1,0],['−1','0'],'Off-task',TEAL),
           ((-.085,.21),[0,.2],['0','0.2'],'FG reduction',GOLD)]
    for j,(ax,col,spec) in enumerate(zip(axs,columns,specs)):
        lim,ticks,ticklabels,label,color=spec
        ax.set_xlim(*lim);ax.set_ylim(-.45,3.55)
        clean(ax,ticks,ticklabels)
        ax.axhspan(2.61,3.53,color='#F0F6F5',zorder=-2)
        ax.set_yticks([3,2,1,0])
        ax.set_yticklabels(['LoRA-Norm',r'F-HNS ($\alpha=0.5$)',r'F-HNS ($\alpha=1$)','Protected flat'] if j==0 else [])
        if j==0:ax.get_yticklabels()[0].set_color(TEAL)
        ax.set_title(label,loc='center',fontsize=8.8,pad=5,color=color)
        if j==0:ax.axvline(16,color=RULE,lw=.6,ls=(0,(2,2)))
        if j>=2:ax.axvline(0,color=MUTED,lw=.6,ls=(0,(3,3)))
        for i,m in enumerate(methods):
            row=stats[stats.method.eq(m)&stats.metric.eq(col)].iloc[0]
            mu,lo,hi=row[['mean','ci_low','ci_high']];y=3-i
            if j>=2 and i==0:
                ax.plot(0,y,'D',ms=3.6,mfc='white',mec=MUTED,mew=.7,zorder=5)
                continue
            c=TEAL if j<2 and i==0 else color
            point_ci(ax,mu,lo,hi,y,c,size=3.9)
            text=f'{mu:.2f}' if j==0 else f'{mu:.4f}' if j==1 else f'{mu:+.2f}'
            ax.annotate(text,(mu,y),xytext=(0,4.8),textcoords='offset points',
                        ha='center',va='bottom',fontsize=8.2,color=c)
    fig.text(.19,.965,'(a) Functional diagnostics',va='top',fontweight='bold',fontsize=9.1)
    fig.text(.51,.965,'(b) Performance change (pp)',va='top',fontweight='bold',fontsize=9.1)
    fig.text(.19,.035,'Mean and 95% bootstrap CI',fontsize=8.4,color=MUTED)
    fig.text(.985,.035,'Change vs. LoRA-Norm; positive is better',ha='right',fontsize=8.4,color=MUTED)
    save(fig,'fig5_3_functional_equalization')

if __name__=='__main__':
    assert len(raw)==126
    assert np.isclose(method_values('hns_f4_s1','energy_ratio').mean(),.0972,atol=5e-5)
    gain_redistribution()
    equalization_stats()
    from refine_fig45 import matched_strength as refined_strength, functional_equalization as refined_equalization
    refined_strength()
    refined_equalization()
    print('Rebuilt three figures, including refined Figures 4 and 5: PDF, SVG, and PNG.')
