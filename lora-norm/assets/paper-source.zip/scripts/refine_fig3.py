#!/usr/bin/env python3
"""Redraw Fig. 3 from all 18 archived, paired checkpoints.

Run from anywhere: python scripts/refine_fig3.py
The FPR panel preserves each LoRA/LoRA-Norm pair. The energy panel shows
all edited checkpoint ratios against their common LoRA reference of 1.
Header values are arithmetic checkpoint means, never geometric means.
Requires numpy, pandas and matplotlib; no network or model inference.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import Rectangle

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'sources/section5_redraw/raw_results.tsv'
OUT = ROOT / 'figures'
INK = '#293639'
MUTED = '#758085'
GREY = '#8F9DA1'
TEAL = '#168781'
PAIR = '#8EBDB8'
RULE = '#CDD9D7'
TEAL_WASH = '#EFF8F6'
SAND_WASH = '#FCF5EA'
ENERGY = '#B07C37'


def load_pairs():
    raw = pd.read_csv(SOURCE, sep='\t')
    frames = [raw.loc[raw.method.eq(method)].set_index('checkpoint')
              for method in ('original_lora', 'hns_f4_s1')]
    a, b = frames
    assert len(a) == len(b) == 18 and a.index.is_unique and b.index.is_unique
    assert set(a.index) == set(b.index)
    b = b.loc[a.index]
    assert np.isfinite(a[['raw_fpr', 'energy_ratio']]).all().all()
    assert np.isfinite(b[['raw_fpr', 'energy_ratio']]).all().all()
    assert np.allclose(a.energy_ratio, 1)
    assert (b.energy_ratio > 0).all()
    assert f'{a.raw_fpr.mean():.2f}' == '2.02'
    assert f'{b.raw_fpr.mean():.2f}' == '7.35'
    assert f'{b.energy_ratio.mean():.4f}' == '0.0972'
    return a, b


def gain_redistribution():
    for font in Path('/usr/share/fonts/opentype/urw-base35').glob('NimbusRoman-*.otf'):
        fm.fontManager.addfont(str(font))
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Nimbus Roman', 'STIXGeneral', 'DejaVu Serif'],
        'mathtext.fontset': 'stix', 'font.size': 8.0,
        'text.color': INK, 'pdf.fonttype': 42, 'ps.fonttype': 42,
        'svg.fonttype': 'none', 'figure.facecolor': 'white',
        'savefig.facecolor': 'white',
    })
    a, b = load_pairs()
    fig = plt.figure(figsize=(5.5, 1.96))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set(xlim=(0, 396), ylim=(0, 141.12))
    ax.axis('off')

    def txt(x, y, s, size=8.0, color=INK, ha='left', **kw):
        return ax.text(x, y, s, fontsize=size, color=color, ha=ha,
                       va='center', **kw)

    def hline(x0, x1, y, color=RULE, lw=.5, **kw):
        ax.plot([x0, x1], [y, y], color=color, lw=lw,
                solid_capstyle='butt', **kw)

    def dot(x, y, edited=True, size=3.0):
        ax.plot(x, y, 'o', ms=size, mfc=TEAL if edited else 'white',
                mec='white' if edited else GREY, mew=.45 if edited else .65,
                zorder=6)

    # Two very light color fields connect headers with the corresponding metric.
    for x0, x1, tint in [(91, 232, TEAL_WASH), (243, 394, SAND_WASH)]:
        ax.add_patch(Rectangle((x0, 16), x1-x0, 123, fc=tint, ec='none', zorder=0))

    # A single method legend replaces repeated labels at every checkpoint.
    dot(6, 131, edited=False, size=3.6)
    txt(13, 131, 'LoRA', 8.2)
    dot(6, 117, edited=True, size=3.6)
    txt(13, 117, 'LoRA-Norm', 8.2)
    txt(3, 100, '18 paired checkpoints', 7.1, MUTED)

    txt(98, 130, 'a', 9.2, TEAL, fontstyle='italic')
    txt(109, 130, 'Functional spread', 8.9)
    txt(250, 130, 'b', 9.2, ENERGY, fontstyle='italic')
    txt(261, 130, 'Relative energy (log)', 8.9)
    txt(98, 113, f'{a.raw_fpr.mean():.2f}  →  {b.raw_fpr.mean():.2f}',
        11.5, TEAL)
    txt(224, 113, 'mean FPR', 7.2, MUTED, ha='right')
    txt(250, 113, f'1  →  {b.energy_ratio.mean():.4f}', 11.5, ENERGY)
    txt(386, 113, 'mean ratio', 7.2, MUTED, ha='right')
    hline(98, 225, 102)
    hline(250, 386, 102, color='#E4D7C5')

    # Physical positions are linear in FPR and logarithmic in energy.
    fpr_x = lambda value: 98 + (value / 16) * 125
    energy_x = lambda value: 254 + (np.log10(value)-np.log10(.018)) / (-np.log10(.018)) * 126
    for tick in [0, 4, 8, 12, 16]:
        xx = fpr_x(tick)
        ax.plot([xx, xx], [16, 96], color='#DCEAE6', lw=.45, zorder=1)
        txt(xx, 8, str(tick), 7.4, MUTED, ha='center')
    for tick, label in [(.02, '0.02'), (.1, '0.1'), (1, '1')]:
        xx = energy_x(tick)
        ax.plot([xx, xx], [16, 96], color='#E7DDD0', lw=.5, zorder=1,
                ls=(0, (2, 2.5)) if tick == 1 else '-')
        txt(xx, 8, label, 7.4, MUTED, ha='center')
    hline(98, 223, 16, lw=.55)
    hline(250, 386, 16, color='#DCCDB8', lw=.55)

    bases = ['Qwen3-8B', 'Llama-3.1-8B-Instruct']
    tasks = [('magicoder', 'Code'), ('metamath', 'Math'), ('tulu', 'Instr.')]
    centers = [[89, 76, 63], [47, 34, 21]]
    for base, rows in zip(bases, centers):
        label = 'Qwen3' if base.startswith('Qwen') else 'Llama 3.1'
        txt(3, rows[1]+4, label, 8.4)
        txt(3, rows[1]-6, '8B', 7.4, MUTED)
        for (task, label), y in zip(tasks, rows):
            txt(51, y, label, 7.9)
            selected = a.loc[a.base.eq(base) & a.task.eq(task)].sort_values('seed')
            edited = b.loc[selected.index]
            assert list(selected.seed) == [42, 43, 44]
            for offset, (_, source), (_, target) in zip(
                    [2.8, 0, -2.8], selected.iterrows(), edited.iterrows()):
                yy = y + offset
                x0, x1 = fpr_x(source.raw_fpr), fpr_x(target.raw_fpr)
                assert x0 <= x1
                hline(x0, x1, yy, PAIR, .72, zorder=3)
                dot(x0, yy, False)
                dot(x1, yy, True)
                # Every LoRA energy ratio is exactly 1; the common reference
                # is encoded once as a dashed line, avoiding 18 redundant spans.
                dot(energy_x(target.energy_ratio), yy, True)
    # The model boundary also runs through both panels for unambiguous alignment.
    hline(3, 84, 55, color=RULE, lw=.6)
    hline(98, 225, 55, color='#CEDFDA', lw=.6)
    hline(250, 386, 55, color='#DFD0BC', lw=.6)

    OUT.mkdir(exist_ok=True)
    for ext in ('pdf', 'svg', 'png'):
        fig.savefig(OUT / f'fig5_1_gain_redistribution.{ext}', dpi=360)
    plt.close(fig)
    print(f'Fig. 3: {len(a)} paired checkpoints; mean FPR '
          f'{a.raw_fpr.mean():.8f} -> {b.raw_fpr.mean():.8f}; '
          f'mean energy ratio {b.energy_ratio.mean():.8f}.')


if __name__ == '__main__':
    gain_redistribution()
