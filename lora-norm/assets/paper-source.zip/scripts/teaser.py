#!/usr/bin/env python3
"""LoRA-Norm teaser: preserve the original layout, enlarge type, shorten labels.

Run: python teaser.py [--out figures/teaser] [--dpi 600]
Requires numpy and matplotlib. Exports PDF, PNG, and editable SVG.
The 5.5-inch output width matches this paper's template. Base font sizes are
8.3-10.5 pt; mathematical subscripts use the renderer's normal reduction.
Original rounded panels, spectra/ghost overlay, transformation box, connecting
arrows, and result dot tracks are retained. Numerical inputs and HNS(4+1)
calculation are unchanged. The spectrum is illustrative, not empirical.
"""
from pathlib import Path
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', type=Path,
                    default=Path(__file__).resolve().parent / 'figures' / 'teaser')
parser.add_argument('--dpi', type=int, default=600)
args = parser.parse_args()
if args.dpi <= 0:
    parser.error('--dpi must be positive')
args.out.parent.mkdir(parents=True, exist_ok=True)
OUT = str(args.out)

# Alternative low-saturation palette: lilac for LoRA, sage for LoRA-Norm.
# Darker companion text colors keep the pale fills legible at paper size.
INK        = "#303B38"
MUTED      = "#707B75"
FAINT      = "#909C94"
PANEL_BG   = "#F9FAF8"
PANEL_EDGE = "#E0E6E0"
GRAY_BAR   = "#D0D7D1"
GRAY_DOT   = "#A2ADA5"
ORANGE     = "#857092"      # legacy name: muted lilac annotation text
HEAD_FILL  = "#B9A9C6"      # pale lilac, original leading gains
GHOST_F    = "#F2EEF5"
GHOST_L    = "#D3C7DE"
TEAL       = "#587563"      # legacy name: muted sage text
GAIN_FILL  = "#9FB9A7"      # pale sage, normalized gains / markers
FLOW       = "#92AB9B"      # sage arrows and connecting lines
BOX_EDGE   = "#AABFB0"
RULE       = "#DEE6DF"

for font in Path('/usr/share/fonts/opentype/urw-base35').glob('NimbusRoman-*.otf'):
    fm.fontManager.addfont(str(font))
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Nimbus Roman", "Times New Roman", "Liberation Serif",
                   "STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.fonttype": "none",
    "text.color": INK,
    "figure.facecolor": "white",
    "savefig.facecolor": "white",
})

# ------------------------------------------------- numbers from the paper --
TARGET = (67.998, 72.083)      # Table 1 / 4
OFF    = (69.551, 72.792)
FG     = (2.708, 0.344)
FPR    = (2.0, 7.3)            # Table 4 (2.023 -> 7.345)

# spectra: illustrative sigma, t produced by the actual HNS(4+1) + nuclear restore
sigma = np.concatenate([[1.00, 0.52], 0.26 * np.exp(-0.16 * np.arange(14))])
f_fast   = lambda z: z * (3.4445 - 4.7750 * z ** 2 + 2.0315 * z ** 4)
f_stable = lambda z: z * (2.0 - 1.5 * z ** 2 + 0.5 * z ** 4)
x = sigma / max(np.linalg.norm(sigma), 1e-7)
for _ in range(4):
    x = f_fast(x)
x = f_stable(x)
t = sigma.sum() / np.clip(x, 0, None).sum() * np.clip(x, 0, None)
r = len(sigma)

# Canvas at the actual paper width; a little extra height accommodates larger type.
W, H = 5.5, 2.4
fig = plt.figure(figsize=(W, H), dpi=180)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 100)
ax.set_ylim(0, 40)
ax.axis("off")

def panel(x0, x1, y0=2.6, y1=37.4):
    ax.add_patch(FancyBboxPatch(
        (x0, y0), x1 - x0, y1 - y0,
        boxstyle="round,pad=0,rounding_size=1.0",
        facecolor=PANEL_BG, edgecolor=PANEL_EDGE, linewidth=0.7, zorder=0))


def rich(xc, y, parts, fs, ha="center"):
    """One text line built from differently coloured chunks."""
    fig.canvas.draw()
    rend = fig.canvas.get_renderer()
    inv = ax.transData.inverted()
    objs, widths = [], []
    for s, col, wgt in parts:
        tx = ax.text(0, y, s, fontsize=fs, color=col, weight=wgt,
                     ha="left", va="center", zorder=6)
        bb = tx.get_window_extent(renderer=rend)
        widths.append(inv.transform((bb.x1, 0))[0] - inv.transform((bb.x0, 0))[0])
        objs.append(tx)
    gap = 0.12
    cx = xc - (sum(widths) + gap * (len(widths) - 1)) / 2 if ha == "center" else xc
    for tx, w in zip(objs, widths):
        tx.set_position((cx, y))
        cx += w + gap


def arrow(x0, y0, x1, y1, color=FLOW, lw=1.0, mut=6):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>",
                                 mutation_scale=mut, linewidth=lw, color=color,
                                 shrinkA=0, shrinkB=0, zorder=4))


def bars(x0, x1, base, vals, scale, colors, width=0.74):
    pitch = (x1 - x0) / len(vals)
    cx = x0 + (np.arange(len(vals)) + 0.5) * pitch
    for c, v, col in zip(cx, vals, colors):
        ax.add_patch(Rectangle((c - pitch * width / 2, base), pitch * width,
                               v * scale, facecolor=col, edgecolor="none", zorder=3))
    ax.plot([x0 - 0.4, x1 + 0.4], [base, base], color="#C5D1C8", lw=0.6, zorder=3)
    ax.text(cx[0], base - 1.1, "1", fontsize=8.3, color=FAINT, ha="center", va="top")
    ax.text(cx[-1], base - 1.1, str(len(vals)), fontsize=8.3, color=FAINT,
            ha="center", va="top")
    return cx


# Original two rounded outer panels and three-part method flow.
panel(1.4, 66.6)
panel(68.6, 98.8)
BASE, SCALE = 14.6, 12.6
LX, RX = (5.0, 21.0), (48.6, 64.6)
LC, RC = 13.0, 56.6

# (a) Before: keep the warm head bars, bracket, and grey tail.
ax.text(3.5, 35.3, "(a)", fontsize=9.5, color=FAINT, va="center")
ax.text(7.4, 35.3, "Trained LoRA", fontsize=10.5, color=INK,
        va="center", weight="bold")
rich(LC, 31.7, [(r"$U$", MUTED, "normal"),
                (r"$\,\mathrm{diag}(\sigma)\,$", ORANGE, "normal"),
                (r"$V^{\top}$", MUTED, "normal")], fs=10.2)
cx = bars(*LX, BASE, sigma, SCALE, [HEAD_FILL, HEAD_FILL] + [GRAY_BAR] * (r - 2))
ax.text(LX[0] - 0.9, BASE + 6.0, r"$\sigma_i$", fontsize=9.3, color=MUTED,
        ha="right", va="center")
bx0, bx1, by = cx[0] - 0.5, cx[1] + 0.5, 28.4
ax.plot([bx0, bx0, bx1, bx1], [by - 0.7, by, by, by - 0.7],
        lw=0.7, color=ORANGE, zorder=4)
ax.text(bx1 + 0.7, by, "Top gains", fontsize=8.8, color=ORANGE, va="center")
rich(LC, 9.8, [("Imbalanced", ORANGE, "bold")], fs=9.8)

# Central transformation: retain both steps, but remove the iteration details.
BX0, BX1, BY0, BY1 = 23.6, 46.0, 12.6, 28.4
BC = (BX0 + BX1) / 2
ax.add_patch(FancyBboxPatch((BX0, BY0), BX1 - BX0, BY1 - BY0,
             boxstyle="round,pad=0,rounding_size=0.8", facecolor="white",
             edgecolor=BOX_EDGE, linewidth=0.85, zorder=3))
ax.text(BC, 25.9, "Rebalance gains", fontsize=9.5, color=INK,
        ha="center", va="center", weight="bold", zorder=5)
ax.text(BC, 23.5, "Newton–Schulz", fontsize=8.8, color=MUTED,
        ha="center", va="center", zorder=5)
ax.plot([BX0 + 2.6, BX1 - 2.6], [21.6, 21.6], lw=0.5, color=RULE, zorder=4)
ax.text(BC, 19.4, "Restore norm", fontsize=9.5, color=INK,
        ha="center", va="center", weight="bold", zorder=5)
ax.text(BC, 15.8, r"$\sum_i t_i \,=\, \sum_i \sigma_i$", fontsize=10.3,
        color=TEAL, ha="center", va="center", zorder=5)
arrow(LX[1] + 0.8, 20.6, BX0 - 0.4, 20.6, lw=1.15, mut=7)
arrow(BX1 + 0.4, 20.6, RX[0] - 0.8, 20.6, lw=1.15, mut=7)
ax.text(BC, 31.2, r"$U,V$ fixed", fontsize=9.5, color=MUTED,
        ha="center", va="center")

# (b) After: preserve the original-spectrum ghost for a direct shape comparison.
ax.text(47.0, 35.3, "(b)", fontsize=9.5, color=FAINT, va="center")
ax.text(51.0, 35.3, "LoRA-Norm", fontsize=10.5, color=INK,
        va="center", weight="bold")
rich(RC, 31.7, [(r"$U$", MUTED, "normal"),
                (r"$\,\mathrm{diag}(t)\,$", TEAL, "normal"),
                (r"$V^{\top}$", MUTED, "normal")], fs=10.2)
gx = RX[0] + (np.arange(r) + 0.5) * (RX[1] - RX[0]) / r
ax.fill_between(gx, BASE, BASE + sigma * SCALE, step="mid", facecolor=GHOST_F,
                edgecolor="none", zorder=1)
ax.plot(gx, BASE + sigma * SCALE, drawstyle="steps-mid", lw=0.7,
        color=GHOST_L, zorder=2)
ax.text(gx[0] + 1.6, BASE + SCALE * 0.82, "Original", fontsize=8.8,
        color=ORANGE, va="center", zorder=2)
bars(*RX, BASE, t, SCALE, [GAIN_FILL] * r, width=0.80)
ax.text(RX[0] - 0.9, BASE + 1.3, r"$t_i$", fontsize=9.3, color=MUTED,
        ha="right", va="center")
rich(RC, 9.8, [("Rebalanced", TEAL, "bold")], fs=9.8)

# Remove the FPR diagnostic line; retain the original practical message.
ax.text(34.0, 5.4, "Data-free · Training-free · No inference overhead",
        fontsize=9.2, color=INK, ha="center", va="center")

# (c) Three evenly spaced metric rows; keep the original dot-and-arrow style.
# Put each delta beside its metric label, with the two values below its track.
# Exact endpoint labels replace the former tick labels and background grid.
PL, PR = 70.9, 96.7
ax.text(PL, 35.3, "(c)", fontsize=9.5, color=FAINT, va="center")
ax.text(PL + 4.0, 35.3, "18-adapter mean", fontsize=10.1,
        color=INK, va="center", weight="bold")
ax.plot([PL + 0.5], [31.4], marker="o", ms=3.8, color=GRAY_DOT, zorder=5)
ax.text(PL + 2.0, 31.4, "LoRA", fontsize=9.1, color=MUTED, va="center")
ax.plot([PL + 11.0], [31.4], marker="o", ms=4.3, color=GAIN_FILL, zorder=5)
ax.text(PL + 12.5, 31.4, "LoRA-Norm", fontsize=9.1, color=TEAL,
        va="center", weight="bold")

# Target and Off-task share the same [66, 74] scale; FG keeps its [0, 3] scale.
TX0, TX1 = 73.0, 95.0


def track(header_y, label, lo, hi, v0, v1, fmt="{:.1f}", delta=None):
    pos = lambda value: TX0 + (value - lo) / (hi - lo) * (TX1 - TX0)
    y = header_y - 3.0
    ax.text(PL, header_y, label, fontsize=9.3, color=INK, va="center")
    ax.text(PR, header_y, delta, fontsize=9.6, color=TEAL, ha="right",
            va="center", weight="bold")
    ax.plot([TX0, TX1], [y, y], color="#E0E7E1", lw=0.9,
            solid_capstyle="round", zorder=2)
    p0, p1 = pos(v0), pos(v1)
    ax.add_patch(FancyArrowPatch((p0, y), (p1, y), arrowstyle="-|>",
                mutation_scale=7.5, linewidth=1.2, color=FLOW,
                shrinkA=2.8, shrinkB=0.6, zorder=3))
    ax.plot([p0], [y], marker="o", ms=4.0, color=GRAY_DOT, zorder=4)
    ax.plot([p1], [y], marker="o", ms=4.8, color=GAIN_FILL, zorder=5)
    ax.text(p0, y - 2.3, fmt.format(v0), fontsize=9.2, color=MUTED,
            ha="center", va="center")
    ax.text(p1, y - 2.3, fmt.format(v1), fontsize=10.0, color=TEAL,
            ha="center", va="center", weight="bold")
    return pos


track(27.8, "Target (%)", 66, 74, *TARGET,
      delta=f"+{TARGET[1]-TARGET[0]:.1f} pp")
track(19.0, "Off-task (%)", 66, 74, *OFF,
      delta=f"+{OFF[1]-OFF[0]:.1f} pp")
track(10.2, "FG (pp)", 0, 3, *FG, fmt="{:.2f}",
      delta=f"−{FG[0]-FG[1]:.2f} pp")
for separator_y in (20.65, 11.85):
    ax.plot([PL, PR], [separator_y, separator_y], color="#E4EAE4",
            lw=0.5, zorder=1)

# Fixed canvas preserves the stated font sizes at width=5.5 inches.
for extension in ('pdf', 'png', 'svg'):
    fig.savefig(OUT + '.' + extension, dpi=args.dpi)
print('Saved', OUT + '.pdf', OUT + '.png', OUT + '.svg')
