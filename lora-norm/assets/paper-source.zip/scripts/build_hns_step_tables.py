#!/usr/bin/env python3
"""Validate the eight-source archive and report the six primary-task sources.

Run from any directory; only Python's standard library is required.
This script aggregates existing scores and does not run model evaluations.
The original archive is preserved. Derived TSVs are written to six_checkpoint.
"""
import csv
import hashlib
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'sources' / 'hns_step_grid' / 'summary'
OUTPUT = ROOT / 'tables'
DERIVED = SOURCE.parent / 'six_checkpoint'
PRIMARY_TASKS = ('magicoder', 'metamath', 'tulu')


def read(name):
    with (SOURCE / name).open(newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle, delimiter='\t'))


wide = read('main_table.tsv')
aggregate = read('step_aggregate.tsv')
paired = read('paired_stats.tsv')
tidy = read('summary.tsv')
assert len(wide) == 8 and len(aggregate) == 10 and len(paired) == 80
assert len(tidy) == 96
by_key = {(row['base'], row['task']): row for row in wide}
assert len(by_key) == 8
for row in tidy:
    column = {'base': 'Base', 'original_lora': 'LoRA'}.get(row['method'])
    if column is None:
        column = 'HNS_' + row['fast_steps'] + '+' + row['stable_steps']
    assert abs(float(row['score']) - float(by_key[row['base'], row['task']][column])) < 1e-12
for row in aggregate:
    gains = [100 * (float(w['HNS_' + row['configuration']]) - float(w['LoRA'])) for w in wide]
    assert abs(statistics.mean(gains) - float(row['mean_gain_pp'])) < 1e-10
    assert abs(statistics.median(gains) - float(row['median_gain_pp'])) < 1e-10
    counts = [sum(g > 1e-10 for g in gains), sum(abs(g) <= 1e-10 for g in gains), sum(g < -1e-10 for g in gains)]
    assert counts == [int(row[k]) for k in ('wins', 'ties', 'losses')]
for row in paired:
    original = by_key[row['base'], row['task']]
    gain = 100 * (float(original['HNS_' + row['configuration']]) - float(original['LoRA']))
    assert abs(gain - float(row['gain_pp'])) < 1e-10

# Restrict only the reported cohort, retaining all original archive files.
archived_aggregate = aggregate
excluded = [row for row in wide if row['task'] not in PRIMARY_TASKS]
wide = [row for row in wide if row['task'] in PRIMARY_TASKS]
paired = [row for row in paired if row['task'] in PRIMARY_TASKS]
tidy = [row for row in tidy if row['task'] in PRIMARY_TASKS]
by_key = {(row['base'], row['task']): row for row in wide}
assert len(wide) == 6 and len(paired) == 60 and len(tidy) == 72
aggregate = []
for source_row in archived_aggregate:
    config = source_row['configuration']
    gains = [100 * (float(w['HNS_' + config]) - float(w['LoRA'])) for w in wide]
    aggregate.append({
        'configuration': config,
        'checkpoints': len(wide),
        'mean_gain_pp': statistics.mean(gains),
        'median_gain_pp': statistics.median(gains),
        'wins': sum(g > 1e-10 for g in gains),
        'ties': sum(abs(g) <= 1e-10 for g in gains),
        'losses': sum(g < -1e-10 for g in gains),
    })

DERIVED.mkdir(parents=True, exist_ok=True)
for name, rows in [('main_table.tsv', wide), ('summary.tsv', tidy),
                   ('paired_stats.tsv', paired), ('step_aggregate.tsv', aggregate)]:
    with (DERIVED / name).open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter='\t')
        writer.writeheader()
        writer.writerows(rows)

nonzero = [row for row in aggregate if row['configuration'] != '0+0']
best = max(nonzero, key=lambda row: row['mean_gain_pp'])
anchor = next(row for row in aggregate if row['configuration'] == '4+1')
fast4 = next(row for row in aggregate if row['configuration'] == '4+0')
provenance = {
    'source_directory': 'sources/hns_step_grid/summary',
    'source_sha256': {name: hashlib.sha256((SOURCE / name).read_bytes()).hexdigest()
                      for name in ('main_table.tsv', 'summary.tsv', 'paired_stats.tsv', 'step_aggregate.tsv')},
    'selection_rule': 'Retain magicoder, metamath and tulu to match the primary adaptation-task scope.',
    'selected_checkpoints': [{'base': row['base'], 'task': row['task']} for row in wide],
    'excluded_checkpoints': [{'base': row['base'], 'task': row['task']} for row in excluded],
    'new_model_evaluations': 0,
    'aggregation': 'Equal mean and median of 100*(edited accuracy - original LoRA accuracy), using unrounded source scores.',
    'paired_statistics': 'Retained without recomputation; bootstrap and ten-comparison Holm correction are within each checkpoint.',
    'nonzero_mean_gain_range_pp': [min(row['mean_gain_pp'] for row in nonzero), best['mean_gain_pp']],
    'best_setting_by_unrounded_mean': best['configuration'],
    'best_minus_4plus1_pp': best['mean_gain_pp'] - anchor['mean_gain_pp'],
    '4plus0_minus_4plus1_pp': fast4['mean_gain_pp'] - anchor['mean_gain_pp'],
    'best_minus_4plus0_pp': best['mean_gain_pp'] - fast4['mean_gain_pp'],
}
(DERIVED / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n', encoding='utf-8')

def save(name, text):
    (OUTPUT / name).write_text('% Auto-generated by scripts/build_hns_step_tables.py; do not edit values manually.\n' + text, encoding='utf-8')


def label(config):
    return r'\textbf{4+1}' if config == '4+1' else '$' + config + '$'


full = r'''\begin{table}[!htbp]
\centering
\small
\setlength{\tabcolsep}{4pt}
\caption{Complete step grid for the six archived checkpoints matching the primary adaptation tasks (percentages). HE/GSM/IF denote HumanEval, GSM8K, and IFEval, evaluated on their corresponding training-task adapters. The bold row label identifies the main $4+1$ setting, not a score maximum.}
\label{tab:hns_step_grid_full}
\begin{tabular}{@{}lrrrrrr@{}}
\toprule
& \multicolumn{3}{c}{Qwen3-8B} & \multicolumn{3}{c}{Llama-3.1-8B-Instruct}\\
\cmidrule(lr){2-4}\cmidrule(lr){5-7}
Setting & HE & GSM & IF & HE & GSM & IF\\
\midrule
'''
bases = ('Qwen3-8B', 'Llama-3.1-8B-Instruct')
tasks = PRIMARY_TASKS
for col in ['Base', 'LoRA', 'HNS_0+0'] + ['HNS_' + r['configuration'] for r in aggregate if r['configuration'] != '0+0']:
    row_label = col if not col.startswith('HNS_') else label(col[4:])
    if col == 'HNS_0+0':
        row_label += ' (rebuild)'
    numbers = [f'{100 * float(by_key[b, t][col]):.2f}' for b in bases for t in tasks]
    full += row_label + ' & ' + ' & '.join(numbers) + r'\\' + '\n'
    if col == 'HNS_0+0':
        full += r'\midrule' + '\n'
full += r'''\bottomrule
\end{tabular}
\end{table}
'''
save('hns_step_grid_full.tex', full)

table = r'''\begin{table}[!htbp]
\centering
\small
\setlength{\tabcolsep}{10pt}
\caption{Fixed-setting gains over original LoRA on the six archived checkpoints matching the primary adaptation tasks (percentage points). Means and medians weight checkpoints equally; wins/ties/losses use unrounded scores.}
\label{tab:hns_step_aggregate}
\begin{tabular}{@{}lrrc@{}}
\toprule
Setting & Mean gain & Median gain & Win / tie / loss\\
\midrule
'''
for row in aggregate:
    row_label = label(row['configuration'])
    if row['configuration'] == '0+0':
        row_label += ' (rebuild)'
    table += row_label + f" & {float(row['mean_gain_pp']):+.2f} & {float(row['median_gain_pp']):+.2f} & {row['wins']} / {row['ties']} / {row['losses']}" + r'\\' + '\n'
    if row['configuration'] == '0+0':
        table += r'\midrule' + '\n'
table += r'''\bottomrule
\end{tabular}
\end{table}
'''
save('hns_step_aggregate.tex', table)

stats = r'''\begin{table}[!htbp]
\centering
\small
\setlength{\tabcolsep}{7pt}
\caption{Archived $4+1$ versus original LoRA on the six primary-task checkpoints: gain and ordinary paired 95\% interval in percentage points. $p_{\mathrm{Holm}}$ adjusts ten within-checkpoint comparisons. Per-checkpoint intervals and adjusted $p$-values are unchanged by the cohort restriction.}
\label{tab:hns_step_anchor_stats}
\begin{tabular}{@{}llrrr@{}}
\toprule
Base & Target & Gain & 95\% interval & $p_{\mathrm{Holm}}$\\
\midrule
'''
names = {'magicoder': 'HumanEval', 'metamath': 'GSM8K', 'tulu': 'IFEval'}
for row in paired:
    if row['configuration'] != '4+1':
        continue
    base_label = 'Qwen' if row['base'] == bases[0] else 'Llama'
    p = float(row['mcnemar_holm_p'])
    p_label = r'$<0.001$' if p < .001 else f'{p:.3f}'
    stats += f"{base_label} & {names[row['task']]} & {float(row['gain_pp']):+.2f} & $[{float(row['ci95_low_pp']):.2f}, {float(row['ci95_high_pp']):.2f}]$ & {p_label}" + r'\\' + '\n'
    if row['base'] == bases[0] and row['task'] == 'tulu':
        stats += r'\midrule' + '\n'
stats += r'''\bottomrule
\end{tabular}
\end{table}
'''
save('hns_step_anchor_stats.tex', stats)
print('Validated the eight-source archive; retained 72 scores and 60 paired differences; recomputed 10 six-checkpoint aggregates and generated 3 tables.')
print(json.dumps({k: provenance[k] for k in ('nonzero_mean_gain_range_pp', 'best_setting_by_unrounded_mean', 'best_minus_4plus1_pp', 'best_minus_4plus0_pp')}, indent=2))
